<?php

// Lazy load
require porto_lib.'/lib/lazy-load/lazy-load.php';